const DEFAULT_STREAM = "https://cdn1.ctgiptv.com/t-sports/tracks-v1a1/mono.ts.m3u8";
const video = document.getElementById("video");
const loader = document.getElementById("loader");
let hls;

function getUrlParam(){
  const params = new URLSearchParams(location.search);
  return params.get("url") || params.get("u") || "";
}

function playStream(url){
  if(!url) return;
  document.getElementById("streamUrl").value = url;
  loader.classList.remove("hidden");
  if(hls){ hls.destroy(); hls = null; }
  if(Hls.isSupported()){
    hls = new Hls({ maxBufferLength: 30, enableWorker: true });
    hls.loadSource(url);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, () => video.play().catch(()=>{}));
    hls.on(Hls.Events.ERROR, () => loader.classList.add("hidden"));
  } else if(video.canPlayType("application/vnd.apple.mpegurl")){
    video.src = url;
    video.play().catch(()=>{});
  }
}

function manualPlay(){
  const url = document.getElementById("streamUrl").value.trim();
  playStream(url);
}

video.addEventListener("playing", () => loader.classList.add("hidden"));
video.addEventListener("waiting", () => loader.classList.remove("hidden"));
video.addEventListener("error", () => loader.classList.add("hidden"));

window.addEventListener("load", () => {
  setTimeout(() => {
    document.getElementById("splash").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
    playStream(getUrlParam() || DEFAULT_STREAM);
  }, 1800);
});
