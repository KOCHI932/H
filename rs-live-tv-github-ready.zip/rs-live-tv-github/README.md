# RS Live TV GitHub Pages Website

Upload these files to a GitHub repository and enable Settings > Pages > Deploy from branch > main.

Use URL parameter:
`https://your-username.github.io/repo-name/?url=https://example.com/live.m3u8`

Change Telegram link in `index.html`:
`https://t.me/your_channel`
